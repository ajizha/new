# -*- coding: utf-8 -*-

from LINEPY import *
from akad.ttypes import *
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from random import randint
from random import choice
import subprocess as cmd
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, six, ast, pytz, wikipedia, urllib3, urllib, urllib.parse, atexit, asyncio, traceback
import requests.packages.urllib3.exceptions as urllib3_exceptions
import requests as rq
from bs4 import BeautifulSoup as bs
import lxml
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2

botStart = time.time()
_session = requests.session()
#client = LINE()
#client = LINE("EMAIL","PASSWORD")
client = LINE("EsBjTVlMhFicSdqDbBG6.ArwyJv0L/9p8LTcaSobCzG.PHjD0rElXVwerSOvtyN/47ijEC5X07fBEE2JId/6nyU=", appName="DESKTOPWIN\t8.0.3HELLO-WORLD\t16.09")
client.log("Auth Token : " + str(client.authToken))
channelToken = client.getChannelResult()
client.log("Channel Token : " + str(channelToken))
readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
limitOpen = codecs.open("limit.json","r","utf-8")
clientMID = client.profile.mid
Bots = [clientMID]
botStart = time.time()
clientProfile = client.getProfile()
clientSettings = client.getSettings()
oepoll = OEPoll(client)
read = json.load(readOpen)
settings = json.load(settingsOpen)
limit = json.load(limitOpen)
temp_flood = {}
anilink = {}
wait = {
    "blocklive": False
}
badWord = ["kntl","gblk","kontol","tytyd","goblok","asw","asu","anjing","bangsat","bngst","bgst","tolol","tll","bego","ppq","sundala","telaso","sundal","tlaso","nub","noob","tolo"]
hiWord = ["halo","hello","hola","aloha","hai","haloo","haii"]

class Waifu():

	def __init__(self):
		print ("WAIFU")

	def Generator(self):
		hasil = []
		pagez = randint(1, 9)
		req1 = "http://jurnalotaku.com/page/{}/?s=%5Bwaifu+wednesday%5D".format(str(pagez))
		req2 = "http://jurnalotaku.com/?s=%5Bwaifu+wednesday%5D"
		reqs = [req1,req2]
		reqz = choice(reqs)
		req = rq.get(reqz)
		soup = bs(req.text, "lxml")
		for xx in soup.find_all('div', {'class':'article-inner-wrapper'}):
			for zz in xx.find_all('div', {'class':'cover size-a has-depth'}):
				for ff in zz.find_all('img'):
					images = ff.get('src')
					namez = ff.get('alt')
					names = namez.replace("[Waifu Wednesday] ","")
					mergez = names + " xxx " + images
					hasil.append(mergez)
		generatedwaifu = choice(hasil)
		return generatedwaifu
		
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    time.sleep(5)
    python = sys.executable
    os.execl(python, python, *sys.argv)

def autoRestart():
    if settings["autoRestart"] == True:
        if time.time() - botStart > int(settings["timeRestart"]):
            backupData()
            time.sleep(5)
            restartBot()
            
def anistream(to,link=None):
	try:
		if link == None:
			req = rq.get("https://www.riie.net/")
			soup = bs(req.text, "lxml")
			linkz = []
			titlez = []
			no = 0 + 1
			ret_ = "[ Streaming Anime Terbaru ]"
			for xx in soup.find_all('div', {'class':'thumbz'}):
				for ee in xx.find_all('a'):
					title = ee.get('title')
					link = ee.get('href')
					titlez.append(title)
					linkz.append(link)
			for numx in range(8):
				titlex = titlez[numx]
				linkx = linkz[numx]
				ret_ += "\n\n{}. {}\n{}".format(str(no), str(titlex), str(linkx))
				no += 1
			ret_ += "\n\nUntuk streaming silahkan ketik :\nanistream *linknya*"
			client.sendMessage(to,ret_)
		else:
			client.sendMessage(to,"Get data...")
			retz_ = "[ Link Streaming ]"
			url = link
			req = rq.get(url + "?mirror=1")
			soup = bs(req.text, "lxml")
			for xx in soup.find_all('source',
			{'type':'video/mp4'}):
				cv = xx.get('src')
			for ss in soup.find_all('video', {'class':'arve-video fitvidsignore'}):
				thumb = ss.get('poster')
			retz_ += "\n\n{}".format(str(cv))
			client.sendImageWithURL(to,thumb)
			client.sendMessage(to,retz_)
	except Exception as error:
		print(error)
		
def jurnalotaku(to,link=None):
	try:
		if link == None:
			req = rq.get("http://jurnalotaku.com/all/page/1")
			soup = bs(req.text, "lxml")
			linkz = []
			titlez = []
			no = 0 + 1
			ret_ = "[ Update terbaru Otaku ]"
			for xx in soup.find_all("div", {"class":"cover size-a has-depth"}):
				for ee in xx.find_all('img'):
					title = ee.get('alt')
				for ff in xx.find_all('a'):
					link = ff.get('href')
				titlez.append(title)
				linkz.append(link)
			for numx in range(8):
				titlex = titlez[numx]
				linkx = linkz[numx]
				ret_ += "\n\n{}. {}\n{}".format(str(no), str(titlex), str(linkx))
				no += 1
			ret_ += "\n\nUntuk detail postnya silahkan ketik :\notaku *linknya*"
			client.sendMessage(to,ret_)
		else:
			client.sendMessage(to,"Get data...")
			retz_ = "[ Detail Post ]"
			url = link
			req = rq.get(url)
			soup = bs(req.content, "html5lib")
			for xx in soup.find_all("div", {"class":"section-wrapper section-article-content"}):
				for ee in xx.find_all("div", {"class":"meta-cover"}):
					for ff in ee.findAll("img"):
						vc = ff.get("src")
				for gg in xx.find_all("div", {"class":"meta-content"}):
					for hh in gg.select("p"):
						cv = hh.getText("p")
						retz_ += "\n\n{}".format(str(cv))
			client.sendImageWithURL(to,vc)
			client.sendMessage(to,retz_)
	except Exception as error:
		print(error)

def SkipLinkPoi(url):
    req = rq.get(url)
    soup = bs(req.text, "lxml")
    for xx in soup.find_all('div', {'class':'col-sm-6'}):
        for zz in xx.find_all('a'):
            link = zz.get('href')
            return link

def SfLeech(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36'
    }
    pageSource = requests.get(url, headers = headers).text
    mainOptions = str(re.search(r'viewerOptions\'\,\ (.*?)\)\;', pageSource).group(1))
    jsonString = json.loads(mainOptions, encoding="utf-8")
    downloadUrl = jsonString["downloadUrl"]
    return downloadUrl
    
def nekopoi(to,link=None):
	if link == None:
		NEKO_DOMAIN = "http://nekopoi.care"
		req = rq.get(NEKO_DOMAIN)
		soup = bs(req.text, "lxml")
		linkz = []
		titlez = []
		no = 0 + 1
		ret_ = "[ Update Terbaru Nekopoi ]"
		for xx in soup.find_all('div', {'class':'eroinfo'}):
			for cc in xx.find_all('h2'):
				for vv in cc.find_all('a'):
					title = vv.get_text()
					link = vv.get('href')
					titlez.append(title)
					linkz.append(link)
		for numx in range(8):
			titlex = titlez[numx]
			linkx = linkz[numx]
			ret_ += "\n\n{}. {}\n{}".format(str(no), str(titlex), str(NEKO_DOMAIN + linkx))
			no += 1
		ret_ += "\n\nUntuk link download silahkan ketik :\nnekodown *linknya*"
		client.sendMessage(to,ret_)
	else:
		client.sendMessage(to,"Get data...")
		retz_ = "[ Link Download ]"
		NEKO_DOMAIN = "http://nekopoi.care"
		url = link
		req = rq.get(url)
		soup = bs(req.text, "lxml")
		thumbz = []
		linkc = []
		for xx in soup.find_all('div', {'class':'thm'}):
			for tt in xx.find_all('img'):
				thumb = tt.get('src')
				thumbz.append(thumb)
		for bb in soup.find_all('div', {'class':'listlink'}):
			for nn in bb.find_all('a'):
				mn = nn.get('href')
				linkc.append(mn)
		thumbs = thumbz[0]
		linkp = linkc[0]
		sflink = SkipLinkPoi(linkp)
		links = SfLeech(sflink)
		retz_ += "\n\n{}".format(str(links))
		client.sendImageWithURL(to, str(NEKO_DOMAIN + thumbs))
		client.sendMessage(to,retz_)

def SkipSiOtong(url):
    req = rq.get(url)
    soup = bs(req.text, "lxml")
    for xx in soup.find_all('div', {'class':'download-link'}):
        for vv in xx.find_all('a'):
            urlx = vv.get('href')
            return urlx

def SkipGreget(url):
    req = rq.get(url)
    soup = bs(req.text, "lxml")
    for xx in soup.find_all('div', {'class':'download-link'}):
        for vv in xx.find_all('a'):
            urlx = vv.get('href')
            return urlx

def GetRedirect(url):
    r = requests.head(url, allow_redirects=True)
    urlx = r.url
    return urlx

def ZSLeech(url):
    LINK_PATTERN = re.compile(r'https?:\/\/www([\d]*)\.zippyshare\.com\/v\/([\w\d]*)\/file\.html')
    INFO_PATTERN = re.compile(r'document\.getElementById\(\'dlbutton\'\)\.href = \"\/d\/([\w\d]*)\/\" \+ \(([\d]*) % ([\d]*) \+ ([\d]*) % ([\d]*)\) \+ \"\/(.*)\";')
    link_match = LINK_PATTERN.match(url)
    subdomain = 'www' + link_match.group(1)
    html = requests.get(link_match.group(0), timeout=10)
    info = INFO_PATTERN.findall(html.text)
    info = info[0]
    link_id = info[0]
    h1 = int(info[1])
    h2 = int(info[2])
    h3 = int(info[3])
    h4 = int(info[4])
    h = str(h1 % h2 + h3 % h4)
    urlx = 'https://' + subdomain + '.zippyshare.com/d/' + link_id + '/' + h + '/' + info[5]
    return urlx

def samehadaku(to,link=None):
	if link == None:
		URL_DOMAIN = "https://www.samehadaku.tv/"
		req = rq.get(URL_DOMAIN)
		soup = bs(req.text, "lxml")
		titlez = []
		linkz = []
		no = 0 + 1
		ret_ = "[ Update Terbaru Samehadaku ]"
		for xx in soup.find_all('a', {'class':'post-thumb'}):
			title = xx.get('title')
			link = xx.get('href')
			titlez.append(title)
			linkz.append(link)
		for numx in range(8):
			titlex = titlez[numx]
			linkx = linkz[numx]
			ret_ += "\n\n{}. {}\n{}".format(str(no), str(titlex), str(linkx))
			no += 1
		ret_ += "\n\nUntuk link download silahkan ketik :\nsamehada *linknya*"
		client.sendMessage(to,ret_)
	else:
		client.sendMessage(to,"Get data...")
		retz_ = "[ Link Download ]"
		url = link
		req = rq.get(url)
		soup = bs(req.text, "lxml")
		linkz = []
		for xx in soup.find_all('img', {'class':'size-full wp-image-60860 aligncenter'}):
			thumb = xx.get('src')
		for ss in soup.find_all('span'):
			for tt in ss.find_all('a'):
				link = tt.get('href')
				linkz.append(link)
		linkx = linkz[19]
		qwe = SkipSiOtong(linkx)
		tre = SkipGreget(qwe)
		vxc = GetRedirect(tre)
		links = ZSLeech(vxc)
		retz_ += "\n\n{}".format(str(links))
		client.sendMessage(to,retz_)

def logError(text):
    client.log("[ ERROR ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))

def mentionMembers(to, mid):
    try:
        group = client.getGroup(to)
        mids = [mem.mid for mem in group.members]
        jml = len(mids)
        arrData = ""
        if mid[0] == mids[0]:
            textx = "[ Tag {} User ]\n".format(str(jml))
        else:
            textx = ""
        arr = []
        for i in mid:
            no = mids.index(i) + 1
            textx += "• {}. ".format(str(no))
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
        if no == jml:
            textx += "[ Berhasil ]"
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def myhelp():
    helpMessage = "[ Daftar Menu ]" + "\n" + \
                  "• Groups" + "\n" + \
                  "• Media" + "\n" + \
                  "• Owner" + "\n" + \
                  "• Prabayar" + "\n" + \
                  "[ Zenbot Publik ]"
    return helpMessage
    
def help():
    helpMessage = "[ Help Group ]" + "\n" + \
                  "• Help" + "\n" + \
                  "• Tag all" + "\n" + \
                  "• Sider" + "\n" + \
                  "• getreader on" + "\n" + \
                  "• getreader off" + "\n" + \
                  "• Me" + "\n" + \
                  "• Mylimit" + "\n" + \
                  "• Checklimit" + "\n" + \
                  "• Info saya" + "\n" + \
                  "• Kontak saya" + "\n" + \
                  "• Groupinfo" + "\n" + \
                  "• Kalender" + "\n" + \
                  "• Gift" + "\n" + \
                  "• @bye" + "\n" + \
                  "• Runtime" + "\n" + \
                  "• Speed" + "\n" + \
                  "• Tentang zenbot" + "\n" + \
                  "[ Zenbot Publik ]"
    return helpMessage
    
def media():
    helpMessage = "[ Help Media ]" + "\n" + \
                  "• Apakah *?*" + "\n" + \
                  "• Lirik *judul*" + "\n" + \
                  "• Bokep *judul*" + "\n" + \
                  "• Cuaca *kota*" + "\n" + \
                  "• Lokasi *kota*" + "\n" + \
                  "• Postig *linkpost*" + "\n" + \
                  "• Instagram *ignya*" + "\n" + \
                  "• Jadwalsholat *kota*" + "\n" + \
                  "• Tentang *a&b*" + "\n" + \
                  "• Cekkelahiran *tg-bl-th*" + "\n" + \
                  "• Quotes" + "\n" + \
                  "• Translate" + "\n" + \
                  "• Berita terkini" + "\n" + \
                  "• Anitoki" + "\n" + \
                  "• Nekopoi" + "\n" + \
                  "• Waifu saya" + "\n" + \
                  "• Jurnalotaku" + "\n" + \
                  "• Samehadaku" + "\n" + \
                  "• Animestreaming" + "\n" + \
                  "[ Tanpa Tanda * ]"
    return helpMessage
    
def owner():
    helpMessage = "[ Help Owner ]" + "\n" + \
                  "• Restart" + "\n" + \
                  "• Leaveall" + "\n" + \
                  "• Clearchat" + "\n" + \
                  "• Grouplist" + "\n" + \
                  "• Listprabayar"  + "\n" + \
                  "• Maxgroup *num*" + "\n" + \
                  "• Broadcast *text*" + "\n" + \
                  "• Addprabayar *@*"  + "\n" + \
                  "• Removeprabayar *@*"  + "\n" + \
                  "• Renewlimit *@*"  + "\n" + \
                  "[ Tanpa Tanda * ]"
    return helpMessage
    
def prabayar():
    helpMessage = "[ Help Prabayar ]" + "\n" + \
                  "• Blocklive" + "\n" + \
                  "• Unblocklive" + "\n" + \
                  "• Youtube *judul*" + "\n" + \
                  "• Youtubemp3 *judul*" + "\n" + \
                  "• Youtubemp4 *judul*" + "\n" + \
                  "• Youtubedownload *link*" + "\n" + \
                  "• Youtubeinfo *judul*" + "\n" + \
                  "• Storyig *ignya*" + "\n" + \
                  "• Invitegroupcall *no*" + "\n" + \
                  "• Sswebsite *link*|fp=Y/T" + "\n" + \
                  "• Wikipedia *judul*" + "\n" + \
                  "• Gambarteks *textnya*" + "\n" + \
                  "• Kirimsms *no.hp|pesan*" + "\n" + \
                  "[ Tanpa Tanda * ]"
    return helpMessage
    
def backupData():
    try:
        satu = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(satu, f, sort_keys=True, indent=4, ensure_ascii=False)
        dua = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(dua, f, sort_keys=True, indent=4, ensure_ascii=False)
        tiga = limit
        f = codecs.open('limit.json','w','utf-8')
        json.dump(tiga, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
atexit.register(backupData)

def extractGroups(groups=[], no=1):
    result = ""
    for gid in groups:
        group = client.getGroup(gid)
        result += "\n%i. %s #%i" %(no, group.name, len(group.members))
        no += 1
    return result

def sendMentionV2(to, text="", mids=[]):
	try:
		arrData = ""
		arr = []
		mention = "@rifkymcz "
		if mids == []:
			raise Exception("Invalid mids")
		if "@!" in text:
			if text.count("@!") != len(mids):
				raise Exception("Invalid mids")
			texts = text.split("@!")
			textx = ""
			for mid in mids:
				textx += str(texts[mids.index(mid)])
				slen = len(textx)
				elen = len(textx) + 15
				arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
				arr.append(arrData)
				textx += mention
			textx += str(texts[len(mids)])
		else:
			textx = ""
			slen = len(textx)
			elen = len(textx) + 15
			arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
			arr.append(arrData)
			textx += mention + str(text)
		client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
	except Exception as error:
		print (error)
    
def extractMention(mids=[], no=1):
	result = ""
	for mid in mids:
		result += "\n%i. @!\n" %no
		no += 1
	return result
	
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        
def Blocklive(to):
    while True:
        try:
            if wait["blocklive"]:
            	client.acquireGroupCallRoute(to)
            time.sleep(86400)
            print("[BLOCKED LIVE START]")
        except Exception as Error:
            print(error)
                    
def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        client.sendMessage(tmp, "Zenbot kembali aktif")
                    except Exception as error:
                        logError(error)
                        
def makeLimit(msg):
    receiver = msg.to
    sender = msg._from
    #clientMID = "ub621484bd88d2486744123db00551d5e"
    to = sender if not msg.toType and sender == clientMID else receiver
    if sender not in limit["limitUser"] and sender not in settings["owner"] + settings["userPrabayar"] + [clientMID]:
        limit["limitUser"][sender] = 50
    elif sender in limit["limitUser"] and sender not in limit["limitCommand"]:
        if limit["limitUser"][sender] == 1:
            contact = client.getContact(sender)
            limit["limitUser"][sender] = limit["limitUser"][sender] - 1
            sendMention(to, sender, "", "Setelah ini, anda tidak bisa lagi menggunakan bot dikarenakan terkena limit (pembatasan penggunaan bot) selama 12 jam.")
            limit["limitCommand"].append(sender)
            limit["limitTime"][sender] = time.time()
        elif limit["limitUser"][sender] > 1:
            limit["limitUser"][sender] = limit["limitUser"][sender] - 1
 
def checkLimit(sender):
    if sender in limit["limitCommand"]:
      return False
    else:
      return True

def autoRenewLimit():
    renew = []
    if limit["limitTime"] != {}:
        for user in limit["limitTime"]:
            if time.time() - limit["limitTime"][user] > 43200:
                renew.append(user)
    for ren in renew:
        if ren in limit["limitCommand"]:
            limit["limitCommand"].remove(ren)
        if ren in limit["limitUser"]:
            del limit["limitUser"][ren]
        if ren in limit["limitTime"]:
            del limit["limitTime"][ren]
        client.sendMessage(ren, "Selamat limit anda telah kembali. Anda bisa kembali menggunakan bot.")
                       
def clientBot(op):
    try:
        if op.type == 0:
            print ("[ 0 ] END OF OPERATION")
            return
        if op.type == 22:
        	client.leaveRoom(op.param1)
        	print ("[22] Notified invite into room")
        if op.type == 21:
        	client.leaveRoom(op.param1)
        	print ("[21] Invite into room")
        if op.type == 5:
        	print ("[5] Auto add")
        	if settings["autoAdd"] == True:
        		client.findAndAddContactsByMid(op.param1)
        	client.sendMessage(op.param1, "Halo {}, terimakasih telah menambahkan saya sebagai teman 😊\nJangan lupa Add Official Account kami di bawah ini :".format(str(client.getContact(op.param1).displayName)))
        	client.sendContact(op.param1, "ucf0212b6b8a150c7479195835b2c9064")
        	arg = "   New Friend : {}".format(str(client.getContact(op.param1).displayName))
        	print (arg)
        if op.type == 15:
        	if op.param2 in Bots:
        		return
        	client.sendMessage(op.param1, client.getContact(op.param2).displayName + ", Goodbye 😊")
        	print ("[15] Member leave")
        if op.type == 19:
        	if op.param2 in Bots:
        		return
        	client.sendMessage(op.param1, client.getContact(op.param2).displayName + ", Jangan main kick😱😱😱")
        	print ("[19] Member di kick")
        if op.type == 17:
        	if op.param2 in Bots:
        		return
        	client.sendMessage(op.param1, client.getContact(op.param2).displayName + ", Selamat Datang 😊")
        	print ("[17] Member join")
        if op.type == 13:
            print ("[ 13 ] NOTIFIED INVITE GROUP")
            groups = client.getGroupIdsJoined()
            group = client.getGroup(op.param1)
            members = [mem.mid for mem in group.members]
            bot = "u7203824a35bdd4cfef2f0d468a2f668c"
            if len(groups) >= int(settings["limitGroup"]):
            	leave = True
            else:
            	leave = False
            if clientMID in op.param3:
            	if op.param2 in settings["owner"]:
            		client.acceptGroupInvitation(op.param1)
            		client.sendMessage(op.param1, "Halo, terimakasih telah mengundang saya, Ini adalah Auto Join khusus Owner 😊")
            		print ("[13] Auto join admin")
            	else:
            		G = client.getGroup(op.param1)
            		if settings["autoJoin"] == True:
            			if settings["autoCancel"]["on"] == True:
            				if len(G.members) <= settings["autoCancel"]["members"]:
            					client.acceptGroupInvitation(op.param1)
            					client.sendMessage(op.param1, "Halo kak, Mohon maaf group kakak membernya kurang dari 20 nih. maaf yak 😊")
            					client.leaveGroup(op.param1)
            				else:
            					client.acceptGroupInvitation(op.param1)
            					client.sendMessage(op.param1, "Halo kak, terima kasih telah mengundang saya 😊")
            					client.sendMessage(op.param1, "Jangan lupa Add Official Account kami di bawah ini :")
            					client.sendContact(op.param1, "ucf0212b6b8a150c7479195835b2c9064")
            					client.sendMessage(op.param1, "Ketik Help di group ini untuk bantuan.")
            				if bot in members:
            					client.acceptGroupInvitation(op.param1)
            					client.sendMessage(op.param1, "Bot Zenbot lainnya terdeteksi berada di dalam group ini, silahkan gunakan salah satunya.")
            					client.leaveGroup(op.param1)
            				if leave == True:
            					try:
            						client.sendMessage(op.param1, "Mohon maaf, group sudah melebihi batas maksimal.")
            						client.leaveGroup(op.param1)
            					except Exception as e:
            						print(e)
            						pass
            						print ("[13] Bot bergabung")
            		else:
            			print ("autoJoin is Off")
        if op.type in [26, 25]:
            if op.type == 26: print ("[ 26 ] RECEIVE MESSAGE")
            else: print ("[ 25 ] SEND MESSAGE")
            msg = op.message
            sender = msg._from
            receiver = msg.to
            text = str(msg.text)
            msg_id = msg.id
            to = receiver
            txt = text.lower()
            anu = checkLimit(sender)
            if anu == False:
                return
            """
            Pasang makeLimit(msg) tiap setelah command contoh
            if msg.text.lower() in ["help"]:
                cl.sendText(msg.to, str(userHelp))
                makeLimit(msg)
            """
            if msg.toType == 0 and sender != client.profile.mid:
            	to = sender
            if msg.contentType == 0:
            	txt = text.lower()
            if receiver in temp_flood:
                if temp_flood[receiver]["expire"] == True:
                    if txt == "open" and sender in settings["owner"]:
                        temp_flood[receiver]["expire"] = False
                        temp_flood[receiver]["time"] = time.time()
                        client.sendMessage(to, "Zenbot kembali aktif")
                    return
                elif time.time() - temp_flood[receiver]["time"] <= 5:
                    temp_flood[receiver]["flood"] += 1
                    if temp_flood[receiver]["flood"] >= 20:
                        temp_flood[receiver]["flood"] = 0
                        temp_flood[receiver]["expire"] = True
                        ret_ = "Spam terdeteksi, Zenbot akan silent selama 30 detik pada ruangan ini atau ketik Open untuk mengaktifkan kembali."
                        client.sendMessage(to, str(ret_))
                else:
                     temp_flood[receiver]["flood"] = 0
                     temp_flood[receiver]["time"] = time.time()
            else:
                temp_flood[receiver] = {
    	            "time": time.time(),
    	            "flood": 0,
    	            "expire": False
                }
            if msg.contentType == 0 and sender not in clientMID and msg.toType == 2:
            	if 'MENTION' in msg.contentMetadata.keys()!=None:
            		names = re.findall(r'@(\w+)',msg.text)
            		mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            		mentionees = mention['MENTIONEES']
            		for mention in mentionees:
            			if mention['M'] in clientMID:
            				client.sendMessage(to,"Ada apa kak TAG aku? Aku BOT loh, kalau ada yang mau di tanyain PC Creatornya aja kak 👇")
            				client.sendContact(to, "ucf0212b6b8a150c7479195835b2c9064")
            				makeLimit(msg)
            				break
            	if settings["badWord"] == True:
            		if sender not in clientMID:
            			for bad in badWord:
            				if bad in txt:
            					client.sendMessage(to,"Ngetik yang baik baik aja kak " + client.getContact(sender).displayName + " 😊")
            					makeLimit(msg)
            			for anu in hiWord:
            				if anu in txt:
            					client.sendMessage(to,"Halo juga kak " + client.getContact(sender).displayName + " 😊")
            					makeLimit(msg)
            if text is None: return
#==============================================================================#
            elif txt == "mylimit":
                sender = msg._from
                if sender in limit["limitUser"]:
                    ret_ = "Limit penggunaan Zenbot anda tersisa %s, Setelah limit mencapai angka 0 anda tidak dapat menggunakan Zenbot selama 12 jam." %(str(limit["limitUser"][sender]))
                    client.sendMessage(to, str(ret_))
                else:
                    client.sendMessage(to, "Anda belum memiliki limit.")
            elif txt == "checklimit":
                if sender in settings["owner"]:
                    client.sendMessage(to, "Tunggu...")
                    if limit["limitUser"] == {}:
                    	client.sendMessage(to, "Tidak ada user limit")
                    else:
                    	ret_ = "[ List User ]"
                    	no = 0
                    	for lu in limit["limitUser"]:
                    		no += 1
                    		contact = client.getContact(lu)
                    		ret_ += "\n%s. %s #%s" %(str(no), str(contact.displayName), str(limit["limitUser"][lu]))
                    	ret_ += "\n[ Total %s ]" %(str(len(limit["limitUser"])))
                    	if limit["limitCommand"] != []:
                    		ret_ += "\n\n[ User Limit ]"
                    		no = 0
                    		for lc in limit["limitCommand"]:
                    			no += 1
                    			contact = client.getContact(lc)
                    			waktus = waktu(limit["limitTime"][lc])
                    			ret_ += "\n%s. %s" %(str(no), str(contact.displayName))
                    		ret_ += "\n[ Total %s ]" %(str(len(limit["limitCommand"])))
                    	client.sendMessage(to, str(ret_))
                else:
                    client.sendMessage(to, "Tunggu...")
                    if limit["limitCommand"] != []:
                    	client.sendMessage(to, "Tidak ada user limit")
                    else:
                    	ret_ = "[ User Limit ]"
                    	no = 0
                    	for lc in limit["limitCommand"]:
                    		no += 1
                    		contact = client.getContact(lc)
                    		waktus = waktu(limit["limitTime"][lc])
                    		ret_ += "\n%s. %s" %(str(no), str(contact.displayName))
                    	ret_ += "\n[ Total %s ]" %(str(len(limit["limitCommand"])))
                    client.sendMessage(to, str(ret_))
                    print ("[Command] Checklimit")
            elif "renewlimit " in txt:
                if sender in settings["owner"]:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                    	if x["M"] in limit["limitUser"]:
                    		del limit["limitUser"][x["M"]]
                    	if x["M"] in limit["limitCommand"]:
                    		limit["limitCommand"].remove(x["M"])
                    	if x["M"] in limit["limitTime"]:
                    		del limit["limitTime"][x["M"]]
                    	client.sendMessage(to, "Berhasil renew limit %s" %(str(client.getContact(x["M"]).displayName)))
                    	print ("[Command] Renewlimit")
            elif txt == "help":
            	helpMessage = myhelp()
            	client.sendMessage(to, str(helpMessage))
            	makeLimit(msg)
            elif txt == "groups":
            	helpMessage = help()
            	client.sendMessage(to, str(helpMessage))
            	makeLimit(msg)
            elif txt == "media":
            	helpMessage = media()
            	client.sendMessage(to, str(helpMessage))
            	makeLimit(msg)
            elif txt == "owner":
            	helpMessage = owner()
            	client.sendMessage(to, str(helpMessage))
            	makeLimit(msg)
            elif txt == "prabayar":
            	helpMessage = prabayar()
            	client.sendMessage(to, str(helpMessage))
            	makeLimit(msg)
            elif txt == "grouplist":
            	if sender in settings["owner"]:
            		client.sendMessage(to, "Tunggu...")
            		groups = client.getGroupIdsJoined()
            		if not groups:
            			client.sendMessage(to, "No group list")
            		result = "[ Daftar Group ]"
            		if len(groups) <= 200:
            			result += "%s" %str(extractGroups(groups))
            			result += "\n\nTotal Group : %i" %len(groups)
            			client.sendMessage(to, result)
            		elif len(groups) > 200 and len(groups) <= 400:
            			result += "%s" %str(extractGroups(groups[0:200]))
            			client.sendMessage(to, result)
            			result = "%s\n\nTotal Groups : %i Groups" %(str(extractGroups(groups[201:len(groups)], 201)), len(groups))
            			client.sendMessage(to, result)
            		elif len(groups) > 400 and len(groups) <= 600:
            			result += "%s" %str(extractGroups(groups[0:200]))
            			client.sendMessage(to, result)
            			result = "%s" %str(extractGroups(groups[201:400], 201))
            			client.sendMessage(to, result)
            			result = "%s\n\nTotal Groups : %i Groups" %(str(extractGroups(groups[401:len(groups)], 401)), len(groups))
            			client.sendMessage(to, result)
            		else:
            			client.sendMessage(to, "Too much groups iam lazy to type")
            	else:
            		client.sendMessage(to, "Anda bukan owner")
            elif txt.startswith("detailgroup ") and sender in settings["owner"]:
            	separate = msg.text.split(" ")
            	number = msg.text.replace(separate[0] + " ","")
            	groups = client.getGroupIdsJoined()
            	ret_ = ""
            	group = groups[int(number)-1]
            	groups = client.getGroup(group)
            	try:
            		gCreator = groups.creator.displayName
            	except:
            		gCreator = "Tidak ditemukan"
            	if groups.members is not None:
            		gMember = str(len(groups.members))
            	else:
            		gMember = "0"
            	if groups.invitee is not None:
            		gPending = str(len(groups.invitee))
            	else:
            		gPending = "0"
            	if groups.preventedJoinByTicket == True:
            		gQr = "Tertutup"
            		gTicket = "Tidak ada"
            	else:
            		gQr = "Terbuka"
            		gTicket = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(group.id)))
            	timeCreated = time.strftime("%d-%m-%Y", time.localtime(int(groups.createdTime) / 1000))
            	path = "http://dl.profile.line-cdn.net/" + groups.pictureStatus
            	ret_ = "[ Informasi Group ]"
            	ret_ += "\n• Nama Group : {}".format(groups.name)
            	ret_ += "\n• ID Group : {}".format(groups.id)
            	ret_ += "\n• Pembuat Group : {}".format(gCreator)
            	ret_ += "\n• Waktu Dibuat : {}".format(str(timeCreated))
            	ret_ += "\n• Jumlah Member : {}".format(str(gMember))
            	ret_ += "\n• Jumlah Pending : {}".format(gPending)
            	ret_ += "\n• Group QR : {}".format(gQr)
            	ret_ += "\n• Group URL : {}".format(gTicket)
            	client.sendImageWithURL(to, path)
            	client.sendMessage(to, str(ret_))
            elif txt.startswith("listmember ") and sender in settings["owner"]:
            	separate = msg.text.split(" ")
            	number = msg.text.replace(separate[0] + " ","")
            	groups = client.getGroupIdsJoined()
            	ret_ = ""
            	try:
            		group = groups[int(number)-1]
            		G = client.getGroup(group)
            		no = 0
            		ret_ = "[ List Member ]"
            		for mem in G.members:
            			no += 1
            			ret_ += "\n " + str(no) + ". " + mem.displayName
            		client.sendMessage(to,"Nama Group: ["+ str(G.name) + "]\n\n" + ret_)
            	except Exception as e:
            		client.sendMessage(to, str(e))
            elif txt == "clearchat":
            	if sender in settings["owner"]:
            		client.removeAllMessages(op.param2)
            		client.sendMessage(to, "Berhasil menghapus semua chat")
            	else:
            		client.sendMessage(to, "Anda bukan owner.")
            elif txt == "leaveall":
            	if sender in settings["owner"]:
            		client.sendMessage(to, "Tunggu...")
            		for gc in client.getGroupIdsJoined():
            			client.sendMessage(gc, "Bot akan keluar dari semua group guna merefresh bot, silahkan di reinvite kembali dalam 3 menit kedepan.")
            			client.leaveGroup(gc)
            	else:
            		client.sendMessage(to, "Anda bukan owner.")
            elif txt == "@bye":
            	if msg.toType == 2:
            		client.sendMessage(to, "Oke, See you next time 😊")
            		client.leaveGroup(to)
            		makeLimit(msg)
            elif txt == "groupinfo":
            	group = client.getGroup(to)
            	try:
            		gCreator = group.creator.displayName
            	except:
            		gCreator = "Tidak ditemukan"
            	if group.invitee is None:
            		gPending = "0"
            	else:
            		gPending = str(len(group.invitee))
            	if group.preventedJoinByTicket == True:
            		gQr = "Tertutup"
            		gTicket = "Tidak ada"
            	else:
            		gQr = "Terbuka"
            		gTicket = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(group.id)))
            	timeCreated = time.strftime("%d-%m-%Y", time.localtime(int(group.createdTime) / 1000))
            	path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
            	ret_ = "[ Informasi Group ]"
            	ret_ += "\n• Nama Group : {}".format(group.name)
            	ret_ += "\n• ID Group : {}".format(group.id)
            	ret_ += "\n• Pembuat Group : {}".format(gCreator)
            	ret_ += "\n• Waktu Dibuat : {}".format(str(timeCreated))
            	ret_ += "\n• Jumlah Member : {}".format(str(len(group.members)))
            	ret_ += "\n• Jumlah Pending : {}".format(gPending)
            	ret_ += "\n• Group QR : {}".format(gQr)
            	ret_ += "\n• Group URL : {}".format(gTicket)
            	client.sendImageWithURL(to, path)
            	client.sendMessage(to, str(ret_))
            	makeLimit(msg)
            elif txt == "kontak saya":
            	client.sendMessage(to, "• Nama mu : " + client.getContact(sender).displayName + "\n\n• Bio mu : \n" + client.getContact(sender).statusMessage + "\n\n• Link profil mu :\nhttp://dl.profile.line-cdn.net/" + client.getContact(sender).pictureStatus)
            	client.sendMessage(to, "• Mid mu : \n" + sender)
            	makeLimit(msg)
            elif txt == "info saya":
            	status = ["• Status Kehidupan : Menjomblo", "• Status Kehidupan : Menjones", "• Status Kehidupan : Menikah", "• Status Kehidupan : Menyendiri"]
            	muka = ["• Wajah : Jelek", "• Wajah : Cantik", "• Wajah : Gagah", "• Wajah : Sederhana", "• Wajah : Rata"]
            	jenis = ["• Jenis kelamin : Laki - laki", "• Jenis kelamin : Perempuan", "• Jenis kelamin : Waria", "• Jenis kelamin : Tidak punya"]
            	client.sendMessage(to, "• Nama : " + client.getContact(msg._from).displayName + "\n" + random.choice(jenis) + "\n" + random.choice(muka) + "\n" + random.choice(status))
            	makeLimit(msg)
            elif txt == "restart":
            	if sender in settings["owner"]:
            		client.sendMessage(to, "Mencoba restart...")
            		client.sendMessage(to, "Mohon tunggu beberapa saat...")
            		restartBot()
            elif txt == "runtime":
            	timeNow = time.time()
            	runtime = timeNow - botStart
            	runtime = format_timespan(runtime)
            	client.sendMessage(to, "Bot sudah berjalan selama {}".format(str(runtime)))
            	makeLimit(msg)
            elif txt == "follow me":
            	client.sendMessage(to, "RIFKY", contentMetadata={'countryCode': 'ID', 'i-installUrl': 'https://github.com/rifkymcz', 'a-packageName': 'com.spotify.music', 'linkUri': 'https://github.com/rifkymcz', 'subText': 'REOL', 'a-installUrl': 'https://github.com/rifkymcz', 'type': 'mt', 'previewUrl': 'https://avatars2.githubusercontent.com/u/31564867', 'a-linkUri': 'https://github.com/rifkymcz', 'text': 'Notitle', 'id': 'mt000000000a6b79f9', 'i-linkUri': 'https://github.com/rifkymcz'}, contentType=0)
            	client.sendMessage(to, "Succes!")
            elif txt == "speed":
            	start = time.time()
            	client.sendMessage(to, "Menghitung kecepatan...")
            	elapsed_time = time.time() - start
            	client.sendMessage(to, "[ Speed ]\nKecepatan mengirim pesan {} detik".format(str(elapsed_time)))
            	makeLimit(msg)
            elif txt == "getreader on":
            	settings["getReader"][receiver] = []
            	client.sendMessage(to, "Berhasil mengaktifkan Get Reader")
            	makeLimit(msg)
            elif txt == "getreader off":
            	if receiver in settings["getReader"]:
            		del settings["getReader"][receiver]
            		client.sendMessage(to, "Berhasil menonaktifkan Get Reader")
            		makeLimit(msg)
            elif txt == "sider":
            	if to in read['readPoint']:
            		client.sendMessage(to, "==== SIDER ====" + read['readMember'][to] + "\n\nWaktu : " + read['waittime'][to])
            		client.sendMessage(to, "Read point auto update ♪")
            		makeLimit(msg)
            		try:
            			del read['readPoint'][to]
            			del read['readMember'][to]
            			del read['waittime'][to]
            		except:
            			pass
            		read['readPoint'][to] = msg_id
            		read['readMember'][to] = ""
            		tz = pytz.timezone("Asia/Jakarta")
            		timeNow = datetime.now(tz=tz)
            		read['waittime'][to] = timeNow.strftime('%H:%M:%S')
            	else:
            		try:
            			del wait2['readPoint'][to]
            			del wait2['readMember'][to]
            			del wait2['waittime'][to]
            		except:
            			pass
            		read['readPoint'][to] = msg.id
            		read['readMember'][to] = ""
            		tz = pytz.timezone("Asia/Jakarta")
            		timeNow = datetime.now(tz=tz)
            		read['waittime'][to] = timeNow.strftime('%H:%M:%S')
            		client.sendMessage(to, "Read point auto update ♪\nSilahkan ketik [Sider] sekali lagi.")
            		makeLimit(msg)
            elif txt == "tag all":
            	makeLimit(msg)
            	if msg.toType == 0:
            		sendMention(to, to)
            	elif msg.toType == 2:
            		group = client.getGroup(to)
            		contact = [mem.mid for mem in group.members]
            		ct1, ct2, ct3, ct4, ct5, jml = [], [], [], [], [], len(contact)
            		if jml <= 100:
            			mentionMembers(to, contact)
            		elif jml > 100 and jml <= 200:
            			for a in range(0, 99):
            				ct1 += [contact[a]]
            			for b in range(100, jml):
            				ct2 += [contact[b]]
            			mentionMembers(to, ct1)
            			mentionMembers(to, ct2)
            		elif jml > 200 and jml <= 300:
            			for a in range(0, 99):
            				ct1 += [contact[a]]
            			for b in range(100, 199):
            				ct2 += [contact[b]]
            			for c in range(200, jml):
            				ct3 += [contact[c]]
            			mentionMembers(to, ct1)
            			mentionMembers(to, ct2)
            			mentionMembers(to, ct3)
            		elif jml > 300 and jml <= 400:
            			for a in range(0, 99):
            				ct1 += [contact[a]]
            			for b in range(100, 199):
            				ct2 += [contact[b]]
            			for c in range(200, 299):
            				ct3 += [contact[c]]
            			for d in range(300, jml):
            				ct4 += [contact[d]]
            			mentionMembers(to, ct1)
            			mentionMembers(to, ct2)
            			mentionMembers(to, ct3)
            			mentionMembers(to, ct4)
            		elif jml > 400 and jml <= 500:
            			for a in range(0, 99):
            				ct1 += [contact[a]]
            			for b in range(100, 199):
            				ct2 += [contact[b]]
            			for c in range(200, 299):
            				ct3 += [contact[c]]
            			for d in range(300, 399):
            				ct4 += [contact[d]]
            			for e in range(400, jml):
            				ct4 += [contact[e]]
            			mentionMembers(to, ct1)
            			mentionMembers(to, ct2)
            			mentionMembers(to, ct3)
            			mentionMembers(to, ct4)
            			mentionMembers(to, ct5)
            elif txt == "me":
            	sendMention(to, sender)
            	client.sendContact(to, sender)
            	makeLimit(msg)
            elif txt == "kalender":
            	tz = pytz.timezone("Asia/Jakarta")
            	timeNow = datetime.now(tz=tz)
            	day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
            	hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
            	bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
            	hr = timeNow.strftime("%A")
            	bln = timeNow.strftime("%m")
            	for i in range(len(day)):
            		if hr == day[i]: hasil = hari[i]
            	for k in range(0, len(bulan)):
            		if bln == str(k): bln = bulan[k-1]
            	readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : " + timeNow.strftime('%H:%M:%S')
            	client.sendMessage(to, readTime)
            	makeLimit(msg)
            elif txt == "gift":
            	client.sendMessage(to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
            	makeLimit(msg)
            elif txt == "tentang zenbot":
            	gids = client.getGroupIdsJoined()
            	cids = client.getAllContactIds()
            	bids = client.getBlockedContactIds()
            	result = "[ Tentang Zenbot ]\n"
            	creator = ["ub621484bd88d2486744123db00551d5e","ucf0212b6b8a150c7479195835b2c9064","udd76b08e9178df926daf94371e9015f1","u5b67c6e4067d095e62c231ee114d8f29","u09abdc8f5c7db2c66a49fcfbf6f96e6f","udf060a89ebb2af83af77edddb767c329","ub37bfd38a22f5f7612166ade5d7a986f","ubb1736a73664d2c1d48e5273c530e1af","u8a1181e344c21d89ebec19769e77eb03","u2469958d85f9d006e6ac3c724985c783","uedcb4744c255b5cf5eb4a43f700a6c32","uf1ecec4f991efbe0a91fc853e783c58f"]
            	result += "\n• Nama : Zenbot Publik"
            	result += "\n• Group : {}".format(str(len(gids)))
            	result += "\n• Teman : {}".format(str(len(cids)))
            	result += "\n• Blokir : {}".format(str(len(bids)))
            	result += "\n• Versi : Stabil v10"
            	result += "\n• Bahasa : ID - EN"
            	result += "\n\n• Pembuat :"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n\n• Di dukung oleh :"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n- @!\n"
            	result += "\n\nCopyright© by Zenbot 2018\nAll Rights Reserved."
            	sendMentionV2(to, str(result), creator)
            elif txt == "animestreaming":
            	anistream(to)
            	makeLimit(msg)
            elif txt.startswith("anistream "):
            	separate = msg.text.split(" ")
            	link = msg.text.replace(separate[0] + " ","")
            	anistream(to,link=link)
            	makeLimit(msg)
            elif txt == "nekopoi":
            	nekopoi(to)
            	makeLimit(msg)
            elif txt.startswith("nekodown "):
            	separate = msg.text.split(" ")
            	link = msg.text.replace(separate[0] + " ","")
            	nekopoi(to,link=link)
            	makeLimit(msg)
            elif txt == "samehadaku":
            	samehadaku(to)
            	makeLimit(msg)
            elif txt.startswith("samehada "):
            	separate = msg.text.split(" ")
            	link = msg.text.replace(separate[0] + " ","")
            	samehadaku(to,link=link)
            	makeLimit(msg)
            elif txt == "jurnalotaku":
            	jurnalotaku(to)
            	makeLimit(msg)
            elif txt.startswith("otaku "):
            	separate = msg.text.split(" ")
            	link = msg.text.replace(separate[0] + " ","")
            	jurnalotaku(to,link=link)
            	makeLimit(msg)
            elif txt == "anitoki":
            	req = requests.get('http://anitoki.com/')
            	soup = BeautifulSoup(req.text, "lxml")
            	no = 1
            	ret_ = "[ Latest Release ]"
            	for xx in soup.find_all('div', {'class':'content'}):
            		zz = xx.find_all('h2')
            		for tt in zz:
            			ss = tt.find_all('a')
            			for ii in ss:
            				title = ii.get('title')
            				link = ii.get('href')
            				ret_ += "\n\n{}. Judul : {}\n    Link : {}".format(str(no), str(title), str(link))
            				no += 1
            	client.sendMessage(to, str(ret_))
            	makeLimit(msg)
            elif txt.startswith("bokep "):
            	separate = msg.text.split(" ")
            	query = msg.text.replace(separate[0] + " ","")
            	with requests.session() as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("https://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search={}".format(urllib2.quote(query)))
            		data = r.text
            		data = json.loads(data)
            		ret_ = "[ Hasil Pencarian ]"
            		no = 1
            		anu = data["videos"]
            		if len(anu) >= 5:
            			for s in range(5):
            				hmm = anu[s]
            				title = hmm['video']['title']
            				duration = hmm['video']['duration']
            				views = hmm['video']['views']
            				link = hmm['video']['embed_url']
            				ret_ += "\n\n{}. Judul : {}\n    Durasi : {}\n    Penonton : {}\n    Link : {}".format(str(no), str(title), str(duration), str(views), str(link))
            				no += 1
            			client.sendMessage(to, str(ret_))
            			makeLimit(msg)
            elif "apakah " in txt and sender not in clientMID:
            	tanya = txt.replace("apakah ","")
            	jawab = ("Ya","Tidak")
            	jawaban = random.choice(jawab)
            	client.sendMessage(to, jawaban)
            	makeLimit(msg)
            elif "tentang " in txt:
            	if sender not in clientMID:
            		key = txt[7:]
            		fakesp = '0123456789'
            		kamp = random.choice(["Status : Wow Amazing 😆","Status : So Sad 😢","Status : Surprise Motherfucker 😂","Status : Pray for him/her 😢"])
            		sp = "".join([random.choice(fakesp) for x in range(2)])
            		ret_ = "Tentang " + key
            		ret_ += "\n\nMenghitung....\n\n"
            		ret_ += "Total prediksi : " + sp
            		ret_ += "%\n" + kamp
            	client.sendMessage(to, str(ret_))
            	makeLimit(msg)
            if txt == "translate":
            	ret_ = "[ Help Translate ]"
            	ret_ += "\nCara menggunakan ?"
            	ret_ += "\nGunakan perintah :\ntr *bahasa* *teksnya*"
            	ret_ += "\n\nContoh :"
            	ret_ += "\ntr id rifky cool"
            	ret_ += "\n\nCara melihat bahasa yang tersedia?"
            	ret_ += "\nGunakan perintah :\ntr bahasa"
            	client.sendMessage(to,str(ret_))
            	makeLimit(msg)
            elif txt == "berita terkini":
            	try:
            		with _session as web:
            			r = web.get("https://corrykalam.gq/chatbot.php?text=berita terkini")
            			try:
            				data = json.loads(r.text)
            				client.sendMessage(to, data["answer"])
            				makeLimit(msg)
            			except:
            				client.sendMessage(to, "Tidak ada hasil ditemukan")
            	except Exception as error:
            		print(error)
            elif "addprabayar" in txt and sender in settings["owner"]:
            	if 'MENTION' in msg.contentMetadata.keys()!= None:
            		names = re.findall(r'@(\w+)', text)
            		mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            		mentionees = mention['MENTIONEES']
            		lists = []
            		for mention in mentionees:
            			if mention["M"] not in lists:
            				lists.append(mention["M"])
            		for ls in lists:
            			settings["userPrabayar"].append(ls)
            		client.sendMessage(to, "Berhasil Menambahkan User Prabayar.")
            elif "removeprabayar" in txt and sender in settings["owner"]:
            	if 'MENTION' in msg.contentMetadata.keys()!= None:
            		names = re.findall(r'@(\w+)', text)
            		mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            		mentionees = mention['MENTIONEES']
            		lists = []
            		for mention in mentionees:
            			if mention["M"] not in lists:
            				lists.append(mention["M"])
            		for ls in lists:
            			settings["userPrabayar"].remove(ls)
            		client.sendMessage(to, "Berhasil Menghapus User Prabayar.")
            elif txt == "listprabayar" and sender in settings["owner"]:
            	if settings["userPrabayar"] == []:
            		client.sendMessage(msg.to,"Tidak Ada User prabayar.")
            	else:
            		admin = "[ Daftar Prabayar ]"
            	for mi_d in settings["userPrabayar"]:
            		admin += "\n• " + client.getContact(mi_d).displayName
            	admin += "\n[ Total User {} ]".format(str(len(settings["userPrabayar"])))
            	client.sendMessage(to, str(admin))
            elif txt == "quotes":
            	try:
            		with _session as web:
            			r = web.get("https://corrykalam.gq/chatbot.php?text=quotes")
            			try:
            				data = json.loads(r.text)
            				ret_ = "[ Random Quotes ]"
            				ret_ += "\n{}".format(data["answer"])
            				client.sendMessage(to, str(ret_))
            				makeLimit(msg)
            			except:
            				client.sendMessage(to, "Tidak ada hasil ditemukan")
            	except Exception as error:
            		print(error)
            elif txt.startswith("broadcast "):
            	if sender in settings["owner"]:
            		sep = text.split(" ")
            		txt = text.replace(sep[0] + " ","")
            		groups = client.getGroupIdsJoined()
            		for group in groups:
            			client.sendMessage(group, "[ Broadcast dari Admin ]\n{}".format(str(txt)))
            		client.sendMessage(to, "Berhasil broadcast ke {} group".format(str(len(groups))))
            	else:
            		client.sendMessage(to,"Anda bukan owner.")
            elif txt.startswith("tr "):
            	separate = msg.text.split(" ")
            	cond = separate
            	bahasa = cond[1]
            	text = msg.text.replace(separate[0] + " " + cond[1] + " ","")
            	if bahasa in ["af", "sq", "ar", "hy", "az", "eu", "be", "bn", "bs", "bg", "ca", "ny", "zh", "zh", "hr", "cs", "da", "nl", "en", "eo", "et", "tl", "fi", "fr", "gl", "ka", "de", "el", "gu", "ht", "ha", "iw", "hi", "hu", "is", "ig", "id", "ga", "it", "ja", "jw", "kn", "kk", "km", "ko", "lo", "la", "lv", "lt", "mk", "mg", "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "fa", "pl", "pt", "pa", "ro", "ru", "sr", "st", "si", "sk", "sl", "so", "es", "su", "sw", "sv", "tg", "ta", "te", "th", "tr", "uk", "ur", "uz", "vi", "cy", "yi", "yo", "zu"]:
            		translator = Translator()
            		hasil = translator.translate(text,dest=bahasa)
            		A = hasil.text
            		client.sendMessage(to, A)
            		makeLimit(msg)
            	elif cond[1] == "bahasa":
            		f = open('country.txt','r')
            		lines = f.readlines()
            		panjang = len(lines)
            		lists = ""
            		for a in lines:
            			lists += str(a)
            		client.sendMessage(to,"[ Daftar Bahasa]\n" + str(lists))
            		makeLimit(msg)
            	else:
            		client.sendMessage(to,"Bahasa tidak ditemukan.")
            elif txt == "blocklive" and sender in settings["userPrabayar"]:
            	wait["blocklive"] = True
            	client.sendMessage(to, "Berhasil block live, Ketik 'unblocklive' untuk Unblock live.")
            	thread = Thread(target=Blocklive, args=(to, ))
            	thread.daemon = True
            	thread.start()
            elif txt == "unblocklive" and sender in settings["userPrabayar"]:
            	wait["blocklive"] = False
            	client.sendMessage(to, "Berhasil unblock live!")
            elif txt.startswith("invitegroupcall ") and sender in settings["userPrabayar"]:
            	if msg.toType == 2:
            		sep = text.split(" ")
            		strnum = text.replace(sep[0] + " ","")
            		num = int(strnum)
            		client.sendMessage(to, "Berhasil mengundang kedalam telponan group")
            		for var in range(0,num):
            			group = client.getGroup(to)
            			members = [mem.mid for mem in group.members]
            			client.acquireGroupCallRoute(to)
            			client.inviteIntoGroupCall(to, contactIds=members)
            			makeLimit(msg)
            elif txt.startswith("maxgroup "):
            	if sender in settings["owner"]:
            		num = txt.replace("maxgroup ","")
            		try:
            			settings["limitGroup"] = int(num)
            			client.sendMessage(to, "Berhasil mengatur limit group menjadi {}".format(str(num)))
            		except:
            			client.sendMessage(to, "Itu bukan angka -_-")
            elif txt.startswith("lirik "):
            	separate = msg.text.split(" ")
            	lirik = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("http://corrykalam.gq/joox.php?song={}".format(urllib2.quote(lirik)))
            		data = r.text
            		data = json.loads(data)
            		ret_ = "• Penyanyi : " + data["singer"]
            		ret_ += "\n• Judul : " + data["title"]
            		ret_ += "\n• Lirik : \n" + data["lyric"]
            	client.sendMessage(to, str(ret_))
            	makeLimit(msg)
            elif txt.startswith("youtubedownload ") and sender in settings["userPrabayar"]:
            	sep = text.split(" ")
            	url = text.replace(sep[0] + " ","")
            	params = {"url": url}
            	with requests.session() as web:
            		web.headers["User-Agent"] = random.choice(settings["userAgent"])
            		r = web.get("http://www.saveitoffline.com/process/?{}".format(urllib.parse.urlencode(params)))
            		try:
            			data = json.loads(r.text)
            			ret_ = "[ Youtube Download ]"
            			ret_ += "\n• Judul : {}".format(str(data["title"]))
            			for res in data["urls"]:
            				ret_ += "\n\n• [ {} ]".format(str(res["label"]))
            				ret_ += "\n{}".format(str(res["id"]))
            			try:
            				path = data["thumbnail"]
            				if settings["server"] == "VPS":
            					client.sendImageWithURL(to, str(path))
            				else:
            					urllib.urlretrieve(path, "res.jpg")
            					client.sendImage(to, "res.jpg")
            			except:
            				pass
            			client.sendMessage(to, str(ret_))
            		except:
            			client.sendMessage(to, "URL tidak valid")
            elif txt.startswith("youtubeinfo ") and sender in settings["userPrabayar"]:
            	sep = text.split(" ")
            	url = text.replace(sep[0] + " ","")
            	params = {"vid": url}
            	with requests.session() as web:
            		web.headers["User-Agent"] = random.choice(settings["userAgent"])
            		r = web.get("http://api.ntcorp.us/yt/download?{}".format(urllib.parse.urlencode(params)))
            		try:
            			data = json.loads(r.text)
            			path = data["info"]["thumbnail"]
            			if settings["server"] == "VPS":
            				client.sendImageWithURL(to, str(path))
            			else:
            				urllib.urlretrieve(path, "res.jpg")
            				client.sendImage(to, "res.jpg")
            			ret_ = "[ Youtube Info ]"
            			ret_ += "\n• Judul : {}".format(str(data["info"]["title"]))
            			ret_ += "\n• Saluran : {}".format(str(data["info"]["channel"].replace("+"," ")))
            			ret_ += "\n• Penonton : {}".format(str(data["info"]["view_count"]))
            			client.sendMessage(to, str(ret_))
            		except:
            			client.sendMessage(to, "URL tidak valid")
            elif txt.startswith("youtubemp4 ") and sender in settings["userPrabayar"]:
            	sep = text.split(" ")
            	link = text.replace(sep[0] + " ","")
            	r = requests.get('http://api.corrykalam.net/apimp4.php?link='+link)
            	data = r.text
            	client.sendVideoWithURL(to,str(data))
            elif txt.startswith("youtubemp3 ") and sender in settings["userPrabayar"]:
            	sep = text.split(" ")
            	link = text.replace(sep[0] + " ","")
            	r = requests.get('http://api.corrykalam.net/apiytmp3.php?link='+link)
            	data = r.text
            	client.sendAudioWithURL(to,str(data))
            elif txt.startswith("youtube ") and sender in settings["userPrabayar"]:
            	sep = text.split(" ")
            	search = text.replace(sep[0] + " ","")
            	params = {"search_query": search}
            	with requests.session() as web:
            		try:
            			web.headers["User-Agent"] = random.choice(settings["userAgent"])
            			r = web.get("https://www.youtube.com/results", params = params)
            			soup = BeautifulSoup(r.content, "html5lib")
            			ret_ = "[ Hasil Pencarian ]"
            			datas = []
            			for data in soup.select(".yt-lockup-title > a[title]"):
            				if "&lists" not in data["href"]:
            					datas.append(data)
            			for data in datas:
            				ret_ += "\n\n• {}".format(str(data["title"]))
            				ret_ += "\nhttps://www.youtube.com{}".format(str(data["href"]))
            			ret_ += "\n\n[ Total Pencarian {} ]".format(len(datas))
            			client.sendMessage(to, str(ret_))
            		except:
            			client.sendMessage(to, "URL tidak valid")
            elif txt.startswith("kirimsms ") and sender in settings["userPrabayar"]:
            	separate = msg.text.split(" ")
            	num = msg.text.replace(separate[0] + " ","")
            	txt_ = num.split("|")
            	if len(txt_) <= 1:
            		client.sendMessage(to, "Format salah")
            	else:
            		pesan = txt_[1]
            		num = txt_[0]
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("http://corrykalam.gq/sms.php?no={}&text={}".format(num, pesan))
            		data = r.text
            		data = json.loads(data)
            		if data["status"] == "Gagal":
            			client.sendMessage(to, data["detail"])
            		else:
            			client.sendMessage(to, data["detail"])
            elif txt.startswith("gambarteks ") and sender in settings["userPrabayar"]:
            	sep = text.split(" ")
            	text_ = text.replace(sep[0] + " ","")
            	web = _session
            	web.headers["User-Agent"] = random.choice(settings["userAgent"])
            	font = random.choice(["arial","comic"])
            	r = web.get("http://api.img4me.com/?text=%s&font=%s&fcolor=FFFFFF&size=35&bcolor=000000&type=jpg" %(urllib.parse.quote(text_),font))
            	data = str(r.text)
            	if "Error" not in data:
            		path = data
            		client.sendImageWithURL(to,path)
            	else:
            		client.sendMessage(to,"[RESULT] %s" %(data.replace("Error: ")))
            elif txt.startswith("wikipedia ") and sender in settings["userPrabayar"]:
            	separate = msg.text.split(" ")
            	location = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("https://corrykalam.gq/chatbot.php?text=apa itu {}?".format(urllib2.quote(location)))
            		data = r.text
            		data = json.loads(data)
            		client.sendMessage(to, data["answer"])
            elif txt.startswith("sswebsite ") and sender in settings["userPrabayar"]:
            	separate = msg.text.split(" ")
            	text = msg.text.replace(separate[0] + " ","")
            	cond = text.split("|")
            	web = cond[0]
            	if cond[1].startswith("fp="):
            		fp = cond[1].replace("fp=","")
            		if fp == "Y":
            			fullpage = "&fullpage=1"
            		elif fp == "T":
            			fullpage = ""
            	path = "http://api.screenshotlayer.com/api/capture?access_key={}&url={}{}&format=JPG".format(settings["access_key"],urllib.parse.quote(web),fullpage)
            	client.sendImageWithURL(to,str(path))
            elif txt.startswith("postig "):
            	separate = msg.text.split(" ")
            	link = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("https://farzain.xyz/api/ig_post.php?id={}".format(link))
            		data = r.text
            		data = json.loads(data)
            		if data["status"] == "success":
            			ret_ = "[ Post Instagram ]"
            			ret_ += "\n• Gambar : \n" + str(data["first_pict"])
            			ret_ += "\n• Video : \n" + str(data["first_video"])
            			ret_ += "\n• Caption : \n" + str(data["caption"])
            			ret_ += "\n• Like : " + str(data["like"])
            		else:
            			ret_ = "[Status Post] Error : Post tidak di temukan."
            		client.sendMessage(to, str(ret_))
            		makeLimit(msg)
            elif txt.startswith("instagram "):
            	separate = msg.text.split(" ")
            	link = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("https://farzain.xyz/api/ig_profile.php?id={}".format(link))
            		data = r.text
            		data = json.loads(data)
            		if data["status"] == "failed":
            			client.sendMessage(to, data["url"])
            		else:
            			ret_ = "[ Profil Instagram ]"
            			ret_ += "\n• Foto : \n" + str(data["info"]["profile_pict"])
            			ret_ += "\n• Bio : \n" + str(data["info"]["bio"])
            			ret_ += "\n• Url Bio : \n" + str(data["info"]["url_bio"])
            			ret_ += "\n• Nama Lengkap : " + str(data["info"]["full_name"])
            			ret_ += "\n• Nama pengguna : " + str(data["info"]["username"])
            			ret_ += "\n• Diikuti : " + str(data["count"]["followers"])
            			ret_ += "\n• Mengikuti : " + str(data["count"]["following"])
            			ret_ += "\n• Postingan : " + str(data["count"]["post"])
            		client.sendMessage(to, str(ret_))
            		makeLimit(msg)
            elif txt.startswith("cekkelahiran "):
            	sep = msg.text.split(" ")
            	tanggal = msg.text.replace(sep[0] + " ","")
            	r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
            	data=r.text
            	data=json.loads(data)
            	lahir = data["data"]["lahir"]
            	usia = data["data"]["usia"]
            	ultah = data["data"]["ultah"]
            	zodiak = data["data"]["zodiak"]
            	client.sendMessage(msg.to,"[ Info Kelahiran ]\n"+"• Tanggal lahir : "+lahir+"\n• Umur : "+usia+"\n• Ulang tahun : "+ultah+"\n• Zodiak : "+zodiak)
            	makeLimit(msg)
            elif txt.startswith("lokasi "):
            	separate = msg.text.split(" ")
            	location = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib2.quote(location)))
            		data = r.text
            		data = json.loads(data)
            		if data[0] != "" and data[1] != "" and data[2] != "":
            			link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
            			ret_ = "[ Status Lokasi ]"
            			ret_ += "\n• Lokasi : " + data[0]
            			ret_ += "\n• Google Maps : " + link
            		else:
            			ret_ = "[Detail Lokasi ] Error : Location tidak di temukan."
            		client.sendMessage(to,str(ret_))
            		makeLimit(msg)
            elif txt.startswith("jadwalsholat "):
            	separate = msg.text.split(" ")
            	location = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("https://corrykalam.gq/chatbot.php?text=jadwal sholat {}".format(urllib2.quote(location)))
            		data = r.text
            		data = json.loads(data)
            		client.sendMessage(to, data["answer"])
            		makeLimit(msg)
            elif txt == "waifu saya":
            	waifu = Waifu()
            	gen = waifu.Generator()
            	genx = gen.split(" xxx ")
            	titlexz = genx[0]
            	linkxz = genx[1]
            	client.sendImageWithURL(to, linkxz)
            	sendMention(to, sender, "", "Waifu mu adalah : " + titlexz)
            	makeLimit(msg)
            elif txt.startswith("cuaca "):
            	separate = msg.text.split(" ")
            	location = msg.text.replace(separate[0] + " ","")
            	with _session as web:
            		web.headers["user-agent"] = random.choice(settings["userAgent"])
            		r = web.get("http://api.corrykalam.net/apicuaca.php?kota={}".format(urllib2.quote(location)))
            		data = r.text
            		data = json.loads(data)
            		tz = pytz.timezone("Asia/Jakarta")
            		timeNow = datetime.now(tz=tz)
            		if "result" not in data:
            			ret_ = "[ Status Cuaca ]"
            			ret_ += "\n• Lokasi : " + data[0].replace("Temperatur di kota ","")
            			ret_ += "\n• Suhu : " + data[1].replace("Suhu : ","") + "°C"
            			ret_ += "\n• Kelembaban : " + data[2].replace("Kelembaban : ","") + "%"
            			ret_ += "\n• Tekanan udara : " + data[3].replace("Tekanan udara : ","") + "HPa"
            			ret_ += "\n• Kecepatan Waktu : " + data[4].replace("Kecepatan angin : ","") + "m/s"
            			ret_ += "\n[ Status Waktu ]"
            			ret_ += "\n• Tanggal : " + datetime.strftime(timeNow,'%Y-%m-%d')
            			ret_ += "\n• Jam : " + datetime.strftime(timeNow,'%H:%M:%S') + " WIB"
            		else:
            			ret_ = "[Status Cuaca] Error : Location tidak di temukan."
            		client.sendMessage(to, str(ret_))
            		makeLimit(msg)
            elif txt.startswith("join ") and sender in settings["owner"]:
            	separate = msg.text.split(" ")
            	res = msg.text.replace(separate[0] + " ","")
            	groups = client.getGroupIdsJoined()
            	try:
            		group = groups[int(res)-1]
            		eue = client.getGroup(group)
            		eue.preventedJoinByTicket = False
            		client.updateGroup(eue)
            		gurl = client.reissueGroupTicket(eue.id)
            		client.sendMessage(group, "Admin Zenbot meminta izin untuk join ke Group ini melalui kode QR.")
            		client.sendMessage(to, "Kode QR Groupnya :\nline://ti/g/" + gurl)
            	except Exception as error:
            		client.sendMessage(to, str(error))
            elif msg.contentType == 16:
            	try:
            		ret_ = "[ Details Post ]"
            		if msg.contentMetadata["serviceType"] == "GB":
            			contact = client.getContact(sender)
            			auth = "\n• Penulis : {}".format(str(contact.displayName))
            		else:
            			auth = "\n• Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
            		purl = "\n• URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
            		ret_ += auth
            		ret_ += purl
            		if "mediaOid" in msg.contentMetadata:
            			object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
            			if msg.contentMetadata["mediaType"] == "V":
            				if msg.contentMetadata["serviceType"] == "GB":
            					ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
            					murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
            				else:
            					ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
            					murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
            				ret_ += murl
            			else:
            				if msg.contentMetadata["serviceType"] == "GB":
            					ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
            				else:
            					ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
            			ret_ += ourl
            		if "stickerId" in msg.contentMetadata:
            			stck = "\n• Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
            			ret_ += stck
            		if "text" in msg.contentMetadata:
            			text = "\n• Tulisan : {}".format(str(msg.contentMetadata["text"]))
            			ret_ += text
            		client.sendMessage(to, str(ret_))
            	except:
            		client.sendMessage(to, "Post tidak valid")
#==============================================================================#
        if op.type == 55:
            print ("[ 55 ] NOTIFIED READ MESSAGE")
            if op.param1 in settings["getReader"] and op.param2 not in settings["getReader"][op.param1]:
            	if "@!" in settings["readerPesan"]:
            		msg = settings["readerPesan"].split("@!")
            		sendMention(op.param1, op.param2, msg[0], msg[1])
            	else:
            		sendMention(op.param1, op.param2, "Halo", settings["readerPesan"])
            	settings["getReader"][op.param1].append(op.param2)
            if op.param1 in read['readPoint']:
            	Name = client.getContact(op.param2).displayName
            	if Name in read['readMember'][op.param1]:
            		pass
            	else:
            		read['readMember'][op.param1] += "\n • " + Name
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
        
def run():
    while True:
        try:
        	autoRestart()
        	autoRenewLimit()
        	delExpire()
        	ops = oepoll.singleTrace(count=50)
        	if ops != None:
        		for op in ops:
        			threading.Thread(target=clientBot(op)).start()
        			oepoll.setRevision(op.revision)
        except Exception as e:
        	logError(e)

if __name__ == "__main__":
    run()