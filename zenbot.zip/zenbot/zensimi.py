 # -*- coding: utf-8 -*-

from LINEPY import *
from akad.ttypes import *
from threading import Thread
import json, time, random, tempfile, os, sys, traceback, codecs, atexit, threading, requests, codecs

client = LINE("EtszBhUs7PO6vs6Kmtk0.V6+R6UrDIa0nX6IDe2eMGa.35dvjjTuU3X2NtCHiqvJjizHl/pHyX8TvoWHCnbU4zE=")
client.log("Auth Token : " + str(client.authToken))
clientMID = client.profile.mid
oepoll = OEPoll(client)
admin = "u2fec7253848eeb35ac258b9364652227"
chatBotName = ""
host = "http://corrykalam.gq"
path = "/simi.php"

profile = client.getProfile()
profile.displayName = "Rey Simi"
client.updateProfile(profile)
    
try:
    with open("chatbot.json", "r", encoding="utf_8_sig") as fp:
        chatBot = json.loads(fp.read())
except:
    print ("simi file not found, simi dict default will used")
    chatBot = ["u2fec7253848eeb35ac258b9364652227"]
	
def backupData():
    with open("chatbot.json", "w", encoding="utf8") as f:
        json.dump(chatBot, f, ensure_ascii=False, indent=4, separators=(',', ': '))
atexit.register(backupData)

def restart_program():
	backupData()
	time.sleep(5)
	python = sys.executable
	os.execl(python, python, * sys.argv)
    
def clientBot(op):
    try:
        if op.type == 0:
            print ("[0] END OF OPERATION")
            return    
#------------------NOTIFIED_INVITE_INTO_ROOM-------------
        if op.type == 22:
            client.leaveRoom(op.param1)
            print ("[22] NOTIFIED INVITE INTO ROOM")
#--------------------INVITE_INTO_ROOM--------------------
        if op.type == 21:
            client.leaveRoom(op.param1)
            print ("[21] NOTIFIED INVITE INTO ROOM")
        if op.type == 5:
            print ("[5] NOTIFIED ADD CONTACT")
            client.findAndAddContactsByMid(op.param1)
            client.sendMessage(op.param1, "Halo {}, terimakasih telah menambahkan saya sebagai teman 😊\nJangan lupa Add Owner kami di bawah ini :".format(str(client.getContact(op.param1).displayName)))
            client.sendContact(op.param1, "u2fec7253848eeb35ac258b9364652227")
        if op.type == 13:
            print ("[13] NOTIFIED INVITE INTO GROUP")
            group = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            anu = group.id
            if clientMID in op.param3:
            	client.acceptGroupInvitation(op.param1)
            	client.sendMessage(op.param1, "Halo kak, terima kasih telah mengundang saya 😊")
            	client.sendMessage(op.param1, "Jangan lupa Add Owner kami di bawah ini :")
            	client.sendContact(op.param1, "u2fec7253848eeb35ac258b9364652227")
            	chatBot.append(op.param1)
        if op.type == 25:
        	print ("[25] SEND MESSAGE")
        if op.type == 26:
            msg = op.message
            print ("[26] RECEIVE MESSAGE")
            text = str(msg.text)
            sender = msg._from
            to = msg._from \
            		if not msg.toType \
            		and msg._from != client.profile.mid \
            		else msg.to
            is_chatbot = True \
            						if msg.to in chatBot \
            						and not msg.contentType \
            						and msg.text \
            						else False
            if is_chatbot:
            	params = {'text': text}
            	headers = {'connection': 'keep-alive'}
            	url = client.server.urlEncode(host, path, params)
            	response = client.server.getContent(url, headers)
            	if response.status_code == 200:
            		rjson = response.json()
            		if rjson["answer"] and rjson["status"] == 200:
            			result = rjson["answer"]
            			for rep in ["simi", "yuu"]:
            				result = result.replace(rep, chatBotName)
            			client.sendMessage(to, result)
            			print ("[26] CHATBOT IN GROUP")
            if msg.toType == 0 and sender != clientMID:
            	to = sender
            if msg.contentType == 0:
            	txt = text.lower()
            if msg.text is not None and sender not in clientMID:
            	if msg.toType == 0:
            		text = msg.text
            		r = requests.get("http://corrykalam.gq/simi.php?text=" + text)
            		data = r.text
            		data = json.loads(data)
            		if data['status'] == 200:
            			client.sendMessage(to, data['answer'])
            			print ("[26] CHATBOT IN PRIVATE CHAT")
            if text is None: return
            elif text.lower() == '@bye' and sender not in clientMID:
                if msg.toType == 2:
                	client.sendMessage(to, "Oke, See you next time 😊")
                	chatBot.remove(to)
                	client.leaveGroup(to)
            elif text.lower() == 'restart' and sender in admin:
                client.sendMessage(to, 'Sukses merestart Bot')
                restart_program()
    except Exception as e:
    	client.log("[RECEIVE_MESSAGE] ERROR : " + str(e))
    	traceback.print_tb(e.__traceback__)
		
def run():
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   thread = Thread(target=clientBot(op))
                   thread.daemon = True
                   thread.start()
                   oepoll.setRevision(op.revision)
        except Exception as e:
            print(e)

if __name__ == "__main__":
    run()